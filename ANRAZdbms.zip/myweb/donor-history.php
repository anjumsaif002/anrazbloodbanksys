<?php
include 'connection.php';

$sql = "SELECT donorName, lastDonatedDate, bloodType, contact, address, CNIC FROM donor";

if (isset($_GET['search'])) {
    $searchCNIC = $_GET['search'];
    $sql .= " WHERE CNIC LIKE ?";
    $params = array("%" . $searchCNIC . "%");
} else {
    $params = array();
}

$stmt = sqlsrv_query($conn, $sql, $params);

if ($stmt === false) {
    die(print_r(sqlsrv_errors(), true));
}

$donorHistory = [];
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    $donorHistory[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donor History</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .content {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        p {
            text-align: center;
            font-size: 1.1em;
            color: #555;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
        }
        td {
            font-size: 1em;
        }
        .search-bar {
            margin-bottom: 20px;
            text-align: center;
        }
        .search-bar input {
            padding: 10px;
            width: 200px;
            font-size: 1em;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    <main>
        <div class="content">
            <h2>Donor History</h2>
            <p>Record of all past donations made by a donor.</p>

            <!-- Search Bar -->
            <div class="search-bar">
                <form method="GET" action="">
                    <input type="text" name="search" placeholder="Search by CNIC" value="<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>">
                    <button type="submit">Search</button>
                </form>
            </div>

            <h3>Donor History Records</h3>
            <table>
                <thead>
                    <tr>
                        <th>Donor Name</th>
                        <th>Donation Date</th>
                        <th>Blood Group</th>
                        <th>Contact</th>
                        <th>Address</th>
                        <th>CNIC</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (count($donorHistory) > 0) {
                        foreach ($donorHistory as $donor) {
                            $donatedDate = $donor['lastDonatedDate'] ? $donor['lastDonatedDate']->format('d-m-Y') : 'N/A';
                            echo "<tr>
                                    <td>" . htmlspecialchars($donor['donorName']) . "</td>
                                    <td>" . htmlspecialchars($donatedDate) . "</td>
                                    <td>" . htmlspecialchars($donor['bloodType']) . "</td>
                                    <td>" . htmlspecialchars($donor['contact']) . "</td>
                                    <td>" . htmlspecialchars($donor['address']) . "</td>
                                    <td>" . htmlspecialchars($donor['CNIC']) . "</td>
                                  </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6'>No donor records found.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>

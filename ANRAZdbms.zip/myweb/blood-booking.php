<?php
include 'connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $booking_id = $_POST['booking_id'];
    $name = $_POST['name'];
    $booking_date = $_POST['booking_date'];
    $blood_group = $_POST['blood_group'];
    $contact_no = $_POST['contact_no'];
    $units_required = $_POST['units_required'];
    $role = $_POST['role'];
    $patient_id = ($_POST['role'] === 'Patient') ? $_POST['patient_id'] : null;
    $donor_id = ($_POST['role'] === 'Donor') ? $_POST['donor_id'] : null;
    $remarks = $_POST['remarks'];

    $query = "INSERT INTO bloodBooking (bloodBookingID, name, bookingDate, bloodType, contact, units, patientID, donorID) 
              VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $params = [$booking_id, $name, $booking_date, $blood_group, $contact_no, $units_required, $patient_id, $donor_id];
    $stmt = sqlsrv_query($conn, $query, $params);

    if ($stmt === false) {
        die(print_r(sqlsrv_errors(), true));
    } else {
        echo "<script>alert('Blood booking successfully recorded!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anraz Blood Bank - Blood Booking</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Original styles retained */
        body {
            background-color: #ffffff;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .content {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        form {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }
        .form-group {
            display: flex;
            flex-direction: column;
            flex: 1 1 calc(50% - 15px);
        }
        label {
            font-weight: bold;
            margin-bottom: 5px;
        }
        input, select, textarea, button {
            padding: 10px;
            font-size: 1em;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 100%;
        }
        textarea {
            resize: vertical;
        }
        .button-group {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            flex: 1 1 100%;
        }
        button {
            cursor: pointer;
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 15px;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #0056b3;
        }
        .conditional-field {
            display: none;
        }
    </style>
    <script>
        function toggleConditionalFields() {
            const role = document.getElementById('role').value;
            const patientField = document.getElementById('patient_id_field');
            const donorField = document.getElementById('donor_id_field');

            if (role === 'Patient') {
                patientField.style.display = 'block';
                donorField.style.display = 'none';
            } else if (role === 'Donor') {
                donorField.style.display = 'block';
                patientField.style.display = 'none';
            } else {
                patientField.style.display = 'none';
                donorField.style.display = 'none';
            }
        }
    </script>
</head>
<body>
    <?php include 'header.php'; ?>
    <main>
        <div class="content">
            <h2>Blood Booking</h2>
            <p>Book blood units for patients or donors.</p>
            <form action="blood-booking.php" method="POST">
                <div class="form-group">
                    <label for="booking_id">Booking ID:</label>
                    <input type="text" id="booking_id" name="booking_id" required>
                </div>
                <div class="form-group">
                    <label for="booking_date">Booking Date:</label>
                    <input type="date" id="booking_date" name="booking_date" required>
                </div>
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="role">Role:</label>
                    <select id="role" name="role" onchange="toggleConditionalFields()" required>
                        <option value="">-- Select Role --</option>
                        <option value="Patient">Patient</option>
                        <option value="Donor">Donor</option>
                    </select>
                </div>
                <div class="form-group conditional-field" id="patient_id_field">
                    <label for="patient_id">Patient ID:</label>
                    <input type="number" id="patient_id" name="patient_id">
                </div>
                <div class="form-group conditional-field" id="donor_id_field">
                    <label for="donor_id">Donor ID:</label>
                    <input type="number" id="donor_id" name="donor_id">
                </div>
                <div class="form-group">
                    <label for="blood_group">Blood Group:</label>
                    <select id="blood_group" name="blood_group" required>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="units_required">Units Required:</label>
                    <input type="number" id="units_required" name="units_required" required>
                </div>
                <div class="form-group">
                    <label for="contact_no">Contact No:</label>
                    <input type="tel" id="contact_no" name="contact_no" required>
                </div>
                <div class="form-group">
                    <label for="remarks">Remarks:</label>
                    <textarea id="remarks" name="remarks" rows="4"></textarea>
                </div>
                <div class="button-group">
                    <button type="submit" name="save">Save</button>
                    <button type="reset" name="reset">Reset</button>
                </div>
            </form>
        </div>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>

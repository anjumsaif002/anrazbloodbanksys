<?php
include 'connection.php';

$message = ''; // Initialize a message variable

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $selected_admin = $_POST['select-admin'];
    $password = $_POST['password'];

    // Validate the selected admin and password
    $query = "SELECT password FROM admins WHERE username = ?";
    $params = [$selected_admin];
    $stmt = sqlsrv_query($conn, $query, $params);

    if ($stmt === false) {
        $message = '<div style="color: red; font-weight: bold;">Error: ' . print_r(sqlsrv_errors(), true) . '</div>';
    } else {
        $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
        if ($row && password_verify($password, $row['password'])) {
            $message = '<div style="color: green; font-weight: bold;">Admin switched successfully!</div>';
        } else {
            $message = '<div style="color: red; font-weight: bold;">Invalid credentials. Please try again.</div>';
        }
    }

    sqlsrv_free_stmt($stmt);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anraz Blood Bank</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <main>
        <div class="content">
            <h2>Switch Admin</h2>

            <!-- Display success or error message -->
            <?php if (!empty($message)) echo $message; ?>

            <form method="POST">
                <label for="select-admin">Select Admin:</label>
                <select id="select-admin" name="select-admin" required>
                    <?php
                    // Fetch admin usernames from the database
                    $query = "SELECT username FROM admins";
                    $stmt = sqlsrv_query($conn, $query);

                    if ($stmt === false) {
                        echo '<option disabled>Error fetching admins</option>';
                    } else {
                        while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
                            echo '<option value="' . htmlspecialchars($row['username']) . '">' . htmlspecialchars($row['username']) . '</option>';
                        }
                        sqlsrv_free_stmt($stmt);
                    }
                    ?>
                </select>

                <label for="password">Password for Selected Admin:</label>
                <input type="password" id="password" name="password" required>

                <button type="submit">Switch Admin</button>
            </form>
        </div>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>

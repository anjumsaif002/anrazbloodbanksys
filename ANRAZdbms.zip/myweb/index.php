<?php
session_start();

// Redirect to login if not logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anraz Blood Bank</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Global styles */
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .hero {
            background: url('https://example.com/blood-donation-hero.jpg') no-repeat center center/cover;
            padding: 100px 20px;
            text-align: center;
            color: #fff;
            height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            background-size: cover;
        }
        .hero h2 {
            font-size: 3em;
            margin: 0;
            line-height: 1.2;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }
        .hero p {
            font-size: 1.2em;
            max-width: 600px;
            margin: 20px auto;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }
        .hero a {
            display: inline-block;
            padding: 15px 30px;
            background-color: #E63946;
            color: #fff;
            text-decoration: none;
            font-size: 1.1em;
            border-radius: 5px;
            margin-top: 20px;
            transition: background-color 0.3s;
        }
        .hero a:hover {
            background-color: #D32F2F;
        }
        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px 0;
            position: relative;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    <main>
        <section class="hero">
            <h2>Welcome to the Anraz Blood Bank</h2>
            <p>Your trusted source for life-saving blood donations. Together, we can make a difference.</p>
            <!-- Link to Test Booking Page -->
            <a href="test-booking.php">Become a Donor</a>
        </section>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>

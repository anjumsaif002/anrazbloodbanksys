<?php
include 'connection.php';

$message = ''; // Initialize a message variable

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id']; // Capture the ID field
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Insert data into the database
    $query = "INSERT INTO admins (adminID, username, password) VALUES (?, ?, ?)";
    $params = [$id, $username, $hashed_password];
    $stmt = sqlsrv_query($conn, $query, $params);

    if ($stmt === false) {
        $message = '<div style="color: red; font-weight: bold;">Error adding user: ' . print_r(sqlsrv_errors(), true) . '</div>';
    } else {
        $message = '<div style="color: green; font-weight: bold;">User added successfully!</div>';
    }

    sqlsrv_free_stmt($stmt);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anraz Blood Bank</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <main>
        <div class="content">
            <h2>Add User</h2>
            
            <!-- Display success or error message -->
            <?php if (!empty($message)) echo $message; ?>

            <form method="POST">
                <label for="id">ID:</label>
                <input type="text" id="id" name="id" required>

                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>

                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>

                <button type="submit">Add User</button>
            </form>
        </div>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anraz Blood Bank - Report Generation</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .content {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        form {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 30px;
        }
        .form-group {
            display: flex;
            flex-direction: column;
            flex: 1 1 calc(50% - 15px); /* Two items per row */
        }
        label {
            font-weight: bold;
            margin-bottom: 5px;
        }
        input, select, button {
            padding: 10px;
            font-size: 1em;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 100%;
        }
        .button-group {
            display: flex;
            justify-content: center;
            gap: 15px;
            flex: 1 1 100%;
            margin-top: 20px;
        }
        button {
            cursor: pointer;
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 15px;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    <main>
        <div class="content">
            <h2>Report Generation</h2>
            <p>Generate lab reports for patients.</p>

            <!-- Report Generation Form -->
            <form action="process_report_generation.php" method="POST">
                <div class="form-group">
                    <label for="report_id">Report ID:</label>
                    <input type="text" id="report_id" name="report_id" required>
                </div>
                <div class="form-group">
                    <label for="patient_name">Patient Name:</label>
                    <input type="text" id="patient_name" name="patient_name" required>
                </div>
                <div class="form-group">
                    <label for="test_type">Test Type:</label>
                    <select id="test_type" name="test_type" required>
                        <option value="CBC">Complete Blood Count (CBC)</option>
                        <option value="LFT">Liver Function Test (LFT)</option>
                        <option value="RFT">Renal Function Test (RFT)</option>
                        <!-- Add more options as needed -->
                    </select>
                </div>
                <div class="form-group">
                    <label for="report_date">Report Date:</label>
                    <input type="date" id="report_date" name="report_date" required>
                </div>
                <div class="form-group">
                    <label for="remarks">Remarks:</label>
                    <textarea id="remarks" name="remarks" rows="4"></textarea>
                </div>
                <div class="button-group">
                    <button type="submit" name="generate_report">Generate Report</button>
                    <button type="button" name="view_report">View Report</button>
                </div>
            </form>
        </div>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>

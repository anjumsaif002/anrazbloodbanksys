<?php
session_start();
include 'connection.php'; // Ensure this file contains your database connection details.

$error_message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect user input
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Query to fetch the user based on the username
    $query = "SELECT * FROM admins WHERE username = ?";
    $params = [$username];

    // Execute the query
    $stmt = sqlsrv_query($conn, $query, $params);

    if ($stmt === false) {
        // Log the error
        error_log("SQL Error: " . print_r(sqlsrv_errors(), true));
        die("An error occurred. Please try again later."); // User-friendly message
    }

    $user = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

    if ($user) {
        // Check if the password matches
        if ($user['password'] === $password) {
            $_SESSION['adminID'] = $user['adminID'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['loggedin'] = true; // Add this line to indicate the user is logged in
            header("Location: index.php");
            exit();
        } else {
            $error_message = "Invalid username or password.";
        }
    } else {
        $error_message = "Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anraz Blood Bank - Login</title>
    <link rel="stylesheet" href="styles.css">
    <?php include 'fheader.php'; ?>
</head>
<body>

<div class="vision-container">
    <p>Our Vision: To Provide Life-Saving Blood to Every Patient in Need. Together, we aim to create a world where no one has to wait for a life-saving transfusion.</p>
</div>

<div class="login-container">
    <button class="login-btn" onclick="openPopup()">LOGIN</button>
</div>

<div class="overlay" id="overlay"></div>

<div class="popup" id="loginPopup">
    <h2>Login</h2>
    
    <!-- Display error message if login fails -->
    <?php if (!empty($error_message)): ?>
        <div class="error-message" style="color: red; font-weight: bold;">
            <?php echo htmlspecialchars($error_message); ?>
        </div>
    <?php endif; ?>

    <!-- Login form -->
    <form method="POST" action="">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <div class="button-container">
            <button type="submit">Submit</button>
            <button type="button" onclick="closePopup()">Cancel</button>
        </div>
    </form>
</div>

<script>
    function openPopup() {
        document.getElementById('loginPopup').style.display = 'block';
        document.getElementById('overlay').style.display = 'block';
        
        setTimeout(() => {
            document.querySelector('#loginPopup input[name="username"]').focus();
        }, 100);
    }

    function closePopup() {
        document.getElementById('loginPopup').style.display = 'none';
        document.getElementById('overlay').style.display = 'none';
    }
</script>

<?php include 'footer.php'; ?>
</body>
</html>

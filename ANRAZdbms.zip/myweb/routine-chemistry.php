<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anraz Blood Bank - Routine Chemistry</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .content {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        p {
            text-align: center;
            font-size: 1.1em;
            color: #555;
        }
        .test-list {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-top: 20px;
        }
        .test-item {
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .test-item h3 {
            margin-bottom: 10px;
            color: #333;
        }
        .test-item p {
            color: #555;
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    <main>
        <div class="content">
            <h2>Routine Chemistry</h2>
            <p>Standard tests to measure levels of various substances in the blood.</p>

            <!-- Routine Chemistry Test List -->
            <div class="test-list">
                <div class="test-item">
                    <h3>Blood Glucose</h3>
                    <p>Measures blood sugar levels to diagnose diabetes or monitor blood sugar control.</p>
                </div>
                <div class="test-item">
                    <h3>Cholesterol</h3>
                    <p>Tests for total cholesterol, LDL, HDL, and triglycerides to assess heart health.</p>
                </div>
                <div class="test-item">
                    <h3>Urea</h3>
                    <p>Helps to assess kidney function by measuring the amount of urea nitrogen in the blood.</p>
                </div>
                <div class="test-item">
                    <h3>Creatinine</h3>
                    <p>Used to evaluate kidney function by measuring the level of creatinine in the blood.</p>
                </div>
                <div class="test-item">
                    <h3>Electrolytes</h3>
                    <p>Measures sodium, potassium, and other electrolytes to evaluate hydration and kidney function.</p>
                </div>
                <div class="test-item">
                    <h3>Liver Function Tests</h3>
                    <p>Includes tests like ALT, AST, and bilirubin to evaluate liver health.</p>
                </div>
            </div>
        </div>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>

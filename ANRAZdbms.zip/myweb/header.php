<fheader class="first-header">
</fheader>
<header class="main-header">
    <div class="header-container">
        <div class="logo-section">
            <!-- Logo -->
            <img src="logo.jpg" alt="Blood Bank Logo" class="logo">
            <!-- Title -->
            <h1>Anraz Blood Bank</h1>
        </div>
        <nav class="navbar">
            <ul class="nav-menu">
                <!-- Home link -->
                <li><a href="index.php">Home</a></li>

                <!-- Blood Bank Dropdown -->
                <li class="dropdown">
                    <a class="dropbtn">Admin</a>
                    <div class="dropdown-content">
                        <a href="admin-add-user.php">Add User</a>
                        <a href="admin-change-password.php">Change Password</a>
                        <a href="admin-switch-user.php">Switch User</a>
                        <a href="login.php">Logout</a>
                    </div>
                </li>

                <li class="dropdown">
                    <a class="dropbtn">Blood Bank</a>
                    <div class="dropdown-content">
                        <a href="inventory.php">Inventory</a>
                        <a href="donor-history.php">Donor History</a>
                        <a href="donor-details.php">Donor Details</a>
                        <a href="donor-screening.php">Donor Screenings</a>
                    </div>
                </li>
                
                <li class="dropdown">
                    <a class="dropbtn">Patient</a>
                    <div class="dropdown-content">
                        <a href="patient-registration.php">Registration</a>
                        <a href="patient-profile.php">Profile</a>
                        <a href="patient-screening.php">Screening</a>
                        <a href="medicine-trials.php">Medicine Trials</a>
                    </div>
                </li>

                <li class="dropdown">
                    <a class="dropbtn">Counter</a>
                    <div class="dropdown-content">
                        <a href="blood-booking.php">Blood Booking</a>
                        <a href="test-booking.php">Test Booking</a>
                    </div>
                </li>

                <li class="dropdown">
                    <a class="dropbtn">Laboratory</a>
                    <div class="dropdown-content">
                        <a href="test-management.php">Test Management</a>
                        <a href="report-generation.php">Report Generation</a>
                        <a href="routine-chemistry.php">Routine Chemistry</a>
                    </div>
                </li>

                <li class="dropdown">
                    <a class="dropbtn">Management Report</a>
                    <div class="dropdown-content">
                        <a href="blood-bank-statement.php">Blood Bank Statement</a>
                        <a href="blood-bank-activity.php">Blood Bank Activity</a>
                        <a href="blood-bank-worksheet.php">Blood Bank Worksheet</a>
                    </div>
                </li>

                <!-- Other Links -->
                <li><a href="about.php">About Us</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>
        </nav>
    </div>
</header>

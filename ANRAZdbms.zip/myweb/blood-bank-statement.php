<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anraz Blood Bank - Blood Bank Statement</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            background-color: #ffffff; /* White background */
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .content {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        .form-group {
            display: flex;
            flex-direction: column;
        }
        .form-row {
            display: flex;
            gap: 20px;
        }
        label {
            font-weight: bold;
            margin-bottom: 5px;
        }
        input, select, textarea, button {
            padding: 10px;
            font-size: 1em;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }
        th {
            background-color: #f2f2f2;
        }
        .button-group {
            display: flex;
            justify-content: space-between;
            gap: 10px;
        }
        button {
            cursor: pointer;
            background-color: #007bff;
            color: #fff;
            border: none;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    <main>
        <div class="content">
            <h2>Blood Bank Statement</h2>
            <p>Overview of blood inventory and financial transactions.</p>
            <form action="process_blood_statement.php" method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label for="statement_id">Statement ID:</label>
                        <input type="text" id="statement_id" name="statement_id" required>
                    </div>
                    <div class="form-group">
                        <label for="statement_date">Statement Date:</label>
                        <input type="date" id="statement_date" name="statement_date" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="address">Address:</label>
                        <input type="text" id="address" name="address" value="Stadium Road, Karachi, Pakistan" readonly>
                    </div>
                    <div class="form-group">
                        <label for="total_units">Total Units:</label>
                        <input type="number" id="total_units" name="total_units" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="total_donations">Total Donations:</label>
                        <input type="number" id="total_donations" name="total_donations" required>
                    </div>
                    <div class="form-group">
                        <label for="total_transfusions">Total Transfusions:</label>
                        <input type="number" id="total_transfusions" name="total_transfusions" required>
                    </div>
                </div>
                <div class="form-group">
                    <label for="financial_summary">Financial Summary:</label>
                    <textarea id="financial_summary" name="financial_summary" rows="4" required></textarea>
                </div>
                <div class="button-group">
                    <button type="submit">Submit</button>
                    <button type="reset">Reset</button>
                </div>
            </form>
        </div>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>

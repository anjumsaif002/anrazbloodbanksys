<?php
$serverName = "DESKTOP-0NQGFJ5\MSSQLSERVER01"; // Replace with your server details
$database = "proj3";                          // Replace with your database name
$uid = "";                                    // Replace with your SQL Server username
$pass = "";                                   // Replace with your SQL Server password

$connection = [
    "Database" => $database,
    "Uid" => $uid,
    "PWD" => $pass,
];

$conn = sqlsrv_connect($serverName, $connection);

if (!$conn) {
    die(print_r(sqlsrv_errors(), true));
} else {
    echo 'Connection established';
}
?>

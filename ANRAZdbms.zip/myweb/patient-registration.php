<?php
include 'connection.php';

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Collect form data
    $patientID = $_POST['patientID'];  // Patient ID from the form
    $name = $_POST['name'];
    $age = $_POST['age'];
    $contact = $_POST['contact'];
    $cnic = $_POST['cnic'];  // CNIC from the form
    $gender = $_POST['gender'];  // Gender from the form
    $bloodGroup = $_POST['blood_group'];
    $address = $_POST['address'];

    // Prepare the SQL query to insert the data into the patient table
    $query = "INSERT INTO patient (patientID, patientName, age, contact, CNIC, gender, bloodType, address) 
              VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    // Parameters for the query
    $params = array($patientID, $name, $age, $contact, $cnic, $gender, $bloodGroup, $address);

    // Execute the query
    $stmt = sqlsrv_query($conn, $query, $params);

    // Check if the query was successful
    if ($stmt === false) {
        die(print_r(sqlsrv_errors(), true));
    } else {
        // Redirect back to the same page (patient-registration.php) with a success message
        header("Location: patient-registration.php?success=true");
        exit(); // Ensure no further code is executed
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Registration</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <main>
        <div class="content">
            <h2>Patient Registration</h2>
            <p>Register new patients and collect their details.</p>
            
            <!-- Check if a success message is set -->
            <?php
            if (isset($_GET['success'])) {
                echo "<p style='color: green; font-weight: bold;'>Patient added successfully!</p>";
            }
            ?>
            
            <form action="patient-registration.php" method="POST">
                <fieldset>
                    <legend>Patient Details</legend>

                    <label for="patientID">Patient ID:</label>
                    <input type="text" id="patientID" name="patientID" placeholder="Enter patient ID" required><br><br>
                    
                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" placeholder="Enter patient's name" required><br><br>
                    
                    <label for="age">Age:</label>
                    <input type="number" id="age" name="age" placeholder="Enter patient's age" required><br><br>
                    
                    <label for="contact">Contact:</label>
                    <input type="tel" id="contact" name="contact" placeholder="Enter contact number" required><br><br>
                    
                    <label for="cnic">CNIC:</label>
                    <input type="text" id="cnic" name="cnic" placeholder="Enter CNIC" required><br><br>
                    
                    <label for="gender">Gender:</label>
                    <select id="gender" name="gender" required>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                    </select><br><br>

                    <label for="blood-group">Blood Group:</label>
                    <select id="blood-group" name="blood_group" required>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                    </select><br><br>

                    <label for="address">Address:</label><br>
                    <textarea id="address" name="address" rows="4" cols="50" placeholder="Enter patient's address" required></textarea><br><br>

                    <input type="submit" value="Register Patient">
                </fieldset>
            </form>
        </div>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>

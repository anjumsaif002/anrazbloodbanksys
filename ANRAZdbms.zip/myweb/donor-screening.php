<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donor Screening</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <main>
        <div class="content">
            <h2>Donor Screening</h2>
            <p>Donor screening is a vital process to ensure the safety and suitability of blood donations. Before donating blood, every donor undergoes a health check and an eligibility assessment to confirm that they meet the necessary criteria for donation.</p>
            
            <h3>Eligibility Criteria for Blood Donation</h3>
            <ul>
                <li>Donors must be in good general health and feel well on the day of donation.</li>
                <li>Age requirements typically range from 18 to 65 years, but some centers may have variations.</li>
                <li>Donors must meet minimum weight requirements (commonly at least 50 kg or 110 lbs).</li>
                <li>Adequate hemoglobin levels are required to ensure the donor can safely give blood.</li>
                <li>Donors should not have any medical conditions or recent infections that may compromise the quality of the blood or the donor's health.</li>
                <li>Travel history, medication use, and other lifestyle factors are assessed to rule out potential risks.</li>
            </ul>

            <p>The screening process ensures that donated blood is safe for recipients and protects the health of donors. It includes answering a detailed questionnaire, a brief physical examination, and testing for certain infectious diseases.</p>
        </div>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>
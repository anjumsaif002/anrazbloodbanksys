<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blood Bank Worksheet</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <main>
        <div class="content">
            <h2>Blood Bank Worksheet</h2>
            <p>Daily logs and work summaries for the blood bank.</p>
            <form action="submit_blood_bank_data.php" method="POST">
                <fieldset>
                    <legend>Blood Bank Information</legend>
                    
                    <label for="date">Date:</label>
                    <input type="date" id="date" name="date" required><br><br>

                    <label for="donor_name">Donor Name:</label>
                    <input type="text" id="donor_name" name="donor_name" required><br><br>

                    <label for="blood_type">Blood Type:</label>
                    <select id="blood_type" name="blood_type" required>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                    </select><br><br>

                    <label for="donation_type">Donation Type:</label>
                    <select id="donation_type" name="donation_type" required>
                        <option value="whole_blood">Whole Blood</option>
                        <option value="plasma">Plasma</option>
                        <option value="platelets">Platelets</option>
                    </select><br><br>

                    <label for="quantity">Quantity Collected (in units):</label>
                    <input type="number" id="quantity" name="quantity" required><br><br>

                    <label for="storage">Storage Location:</label>
                    <input type="text" id="storage" name="storage" required><br><br>

                    <label for="notes">Additional Notes:</label><br>
                    <textarea id="notes" name="notes" rows="4" cols="50"></textarea><br><br>

                    <input type="submit" value="Submit Worksheet">
                </fieldset>
            </form>
        </div>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>

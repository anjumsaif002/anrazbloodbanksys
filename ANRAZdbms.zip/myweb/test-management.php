<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anraz Blood Bank - Test Management</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .content {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h2, h3 {
            text-align: center;
            color: #333;
        }
        form {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 30px;
        }
        .form-group {
            display: flex;
            flex-direction: column;
            flex: 1 1 calc(50% - 15px); /* Two items per row */
        }
        .form-group textarea {
            resize: vertical;
        }
        label {
            font-weight: bold;
            margin-bottom: 5px;
        }
        input, select, textarea, button {
            padding: 10px;
            font-size: 1em;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 100%;
        }
        .button-group {
            display: flex;
            justify-content: center;
            gap: 15px;
            flex: 1 1 100%;
            margin-top: 20px;
        }
        button {
            cursor: pointer;
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 15px;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #0056b3;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table th, table td {
            padding: 10px;
            text-align: center;
            border: 1px solid #ddd;
        }
        table th {
            background-color: #f4f4f4;
        }
        .actions button {
            background-color: #f44336;
            color: white;
        }
        .actions button:hover {
            background-color: #d32f2f;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    <main>
        <div class="content">
            <h2>Test Management</h2>
            <p>Register and manage laboratory tests.</p>
            
            <!-- Test Registration Form -->
            <form action="process_test_registration.php" method="POST">
                <div class="form-group">
                    <label for="test_code">Test Code:</label>
                    <input type="text" id="test_code" name="test_code" required>
                </div>
                <div class="form-group">
                    <label for="test_name">Test Name:</label>
                    <input type="text" id="test_name" name="test_name" required>
                </div>
                <div class="form-group">
                    <label for="test_description">Description:</label>
                    <textarea id="test_description" name="test_description" rows="4"></textarea>
                </div>
                <div class="form-group">
                    <label for="test_price">Test Price (PKR):</label>
                    <input type="number" id="test_price" name="test_price" required>
                </div>
                <div class="form-group">
                    <label for="test_date">Test Date:</label>
                    <input type="date" id="test_date" name="test_date" required>
                </div>
                <div class="button-group">
                    <button type="submit" name="register">Register Test</button>
                    <!-- Edit Button, can be linked to an editing feature or function -->
                    <button type="button" name="edit">Edit Test</button>
                </div>
            </form>

            <!-- Table to display registered tests (for example) -->
            <h3>Registered Tests</h3>
            <table>
                <thead>
                    <tr>
                        <th>Test Code</th>
                        <th>Test Name</th>
                        <th>Description</th>
                        <th>Price (PKR)</th>
                        <th>Test Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Dynamic table rows to be added here -->
                    <tr>
                        <td>001</td>
                        <td>CBC</td>
                        <td>Complete Blood Count</td>
                        <td>1000</td>
                        <td>2025-01-01</td>
                        <td class="actions">
                            <button>Edit</button>
                            <button>Delete</button>
                        </td>
                    </tr>
                    <!-- More rows as needed -->
                </tbody>
            </table>
        </div>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>

<?php
include 'connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $trialName = $_POST['trial_name'];
    $trialStatus = $_POST['trial_status'];
    $duration = $_POST['duration'];
    $trialNotes = $_POST['trial_notes']; // Optional for additional trial details

    // Insert data into the medicineTrials table
    $query = "INSERT INTO medicineTrials (trialName, status, duration) VALUES (?, ?, ?)";
    $params = array($trialName, $trialStatus, $duration);
    $stmt = sqlsrv_query($conn, $query, $params);

    if ($stmt === false) {
        die(print_r(sqlsrv_errors(), true));
    }

    // Redirect back to the medicine trials page
    header("Location: medicine_trials.php");
    exit();
}
?>
<?php
include 'connection.php';

// Fetch all medicine trials from the database
$query = "SELECT trialName, status, duration FROM medicineTrials";
$stmt = sqlsrv_query($conn, $query);

if ($stmt === false) {
    die(print_r(sqlsrv_errors(), true));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medicine Trials</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <main>
        <div class="content">
            <h2>Medicine Trials</h2>
            <p>Record and track ongoing medication trials for patients.</p>
            
            <!-- Form to submit a new medicine trial -->
            <form action="submit_medicine_trial.php" method="POST">
                <fieldset>
                    <legend>Medicine Trial Details</legend>

                    <label for="trial_name">Trial Name:</label>
                    <input type="text" id="trial_name" name="trial_name" required><br><br>

                    <label for="trial_status">Status:</label>
                    <select id="trial_status" name="trial_status" required>
                        <option value="Ongoing">Ongoing</option>
                        <option value="Completed">Completed</option>
                        <option value="Paused">Paused</option>
                    </select><br><br>

                    <label for="duration">Duration (in weeks):</label>
                    <input type="number" id="duration" name="duration" min="1" required><br><br>

                    <label for="trial_notes">Trial Notes:</label><br>
                    <textarea id="trial_notes" name="trial_notes" rows="4" cols="50" placeholder="Enter details about the trial..." required></textarea><br><br>

                    <input type="submit" value="Submit Trial Details">
                </fieldset>
            </form>

            <!-- Display ongoing trials -->
            <h3>Ongoing Trials</h3>
            <table>
                <thead>
                    <tr>
                        <th>Trial Name</th>
                        <th>Status</th>
                        <th>Duration (weeks)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['trialName']); ?></td>
                            <td><?php echo htmlspecialchars($row['status']); ?></td>
                            <td><?php echo htmlspecialchars($row['duration']); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>

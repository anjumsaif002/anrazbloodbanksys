<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donor Report Form</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <main>
        <div class="content">
            <h2>Donor Report</h2>
            <p>Submit detailed reports regarding donor donation history and eligibility.</p>
            <form action="submit_donor_report.php" method="POST">
                <fieldset>
                    <legend>Donor Report Information</legend>

                    <label for="donor_name">Donor Name:</label>
                    <input type="text" id="donor_name" name="donor_name" required><br><br>

                    <label for="donation_date">Donation Date:</label>
                    <input type="date" id="donation_date" name="donation_date" required><br><br>

                    <label for="donation_type">Donation Type:</label>
                    <select id="donation_type" name="donation_type" required>
                        <option value="whole_blood">Whole Blood</option>
                        <option value="plasma">Plasma</option>
                        <option value="platelets">Platelets</option>
                    </select><br><br>

                    <label for="donation_result">Donation Result:</label><br>
                    <textarea id="donation_result" name="donation_result" rows="4" cols="50" placeholder="Enter donation results here..." required></textarea><br><br>

                    <label for="eligibility">Eligibility Status:</label><br>
                    <textarea id="eligibility" name="eligibility" rows="4" cols="50" placeholder="Enter eligibility status..." required></textarea><br><br>

                    <label for="doctor_comments">Doctor's Comments:</label><br>
                    <textarea id="doctor_comments" name="doctor_comments" rows="4" cols="50" placeholder="Any comments from the doctor..." required></textarea><br><br>

                    <input type="submit" value="Submit Donor Report">
                </fieldset>
            </form>

            <h3>Download Donor Reports</h3>
            <div>
                <button onclick="window.location.href='download_donor_reports.php'">Download Reports</button>
            </div>
        </div>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>

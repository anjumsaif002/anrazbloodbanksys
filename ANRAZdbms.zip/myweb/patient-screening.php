<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Screening</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <main>
        <div class="content">
            <h2>Patient Screening</h2>
            <p>Patient screening is a crucial process to ensure that the blood transfusion is safe and compatible with the recipient's body. This process involves verifying the patient's blood type, health condition, and other factors to minimize risks associated with transfusion.</p>
            
            <h3>Factors Considered for Blood Compatibility</h3>
            <ul>
                <li><strong>Blood Type Matching:</strong> Patients must receive blood from a donor with a compatible blood type (e.g., A, B, AB, or O) and Rh factor (positive or negative).</li>
                <li><strong>Cross-Matching Tests:</strong> A cross-matching procedure is performed to ensure the donor's blood is compatible with the recipient's blood and to avoid adverse reactions.</li>
                <li><strong>Allergic Reactions:</strong> Screening for potential allergies or sensitivities to certain components in the donated blood.</li>
                <li><strong>Patient's Health Condition:</strong> Pre-existing conditions such as heart disease, kidney disorders, or immune system issues are evaluated to ensure the transfusion is safe.</li>
                <li><strong>Volume Requirements:</strong> Determining the appropriate volume of blood or blood components needed for the patient.</li>
            </ul>

            <p>The patient screening process helps prevent complications such as hemolytic reactions, allergic reactions, or infections. By ensuring proper blood compatibility, both the safety of the patient and the effectiveness of the transfusion are prioritized.</p>
        </div>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>
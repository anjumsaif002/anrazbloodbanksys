<fheader class="first-header">
</fheader>
<header class="fheader">
    <div class="header-container">
        <div class="logo-section">
            <!-- Logo -->
            <img src="logo.jpg" alt="Blood Bank Logo" class="logo">
            <!-- Title -->
            <h1>Anraz Blood Bank</h1>
        </div>
    </div>
</header>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donor Details Form</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <main>
        <div class="content">
            <h2>Donor Details</h2>
            <p>Provide personal and contact information of the donor, along with their blood group and eligibility status.</p>
            <form action="submit_donor_details.php" method="POST">
                <fieldset>
                    <legend>Donor Information</legend>
                    
                    <label for="name">Full Name:</label>
                    <input type="text" id="name" name="name" required><br><br>

                    <label for="dob">Date of Birth:</label>
                    <input type="date" id="dob" name="dob" required><br><br>

                    <label for="contact">Contact Number:</label>
                    <input type="tel" id="contact" name="contact" pattern="[0-9]{10}" required><br><br>

                    <label for="email">Email Address:</label>
                    <input type="email" id="email" name="email" required><br><br>

                    <label for="blood_group">Blood Group:</label>
                    <select id="blood_group" name="blood_group" required>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                    </select><br><br>

                    <label for="eligibility">Eligibility for Donation:</label><br>
                    <input type="radio" id="eligible" name="eligibility" value="Eligible" required>
                    <label for="eligible">Eligible</label><br>
                    <input type="radio" id="not_eligible" name="eligibility" value="Not Eligible">
                    <label for="not_eligible">Not Eligible</label><br><br>

                    <label for="address">Home Address:</label><br>
                    <textarea id="address" name="address" rows="4" cols="50" required></textarea><br><br>

                    <label for="medical_history">Medical History:</label><br>
                    <textarea id="medical_history" name="medical_history" rows="4" cols="50"></textarea><br><br>

                    <input type="submit" value="Submit Donor Details">
                </fieldset>
            </form>
        </div>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>

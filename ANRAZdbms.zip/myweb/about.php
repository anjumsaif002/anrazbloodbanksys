<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anraz Blood Bank</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <main>
    <div class="hero about-section">
        <h2><b>About</b></h2>
        <p>
            At <b>ANRAZ Blood Bank</b>, we are committed to saving lives by ensuring the availability of safe and high-quality blood for those in need. 
            Established with the mission to bridge the gap between donors and patients, we strive to provide a reliable and efficient blood donation and distribution system.
        </p>
        <p>
            We believe in the power of community and compassion. Our dedicated team works tirelessly to raise awareness about the importance of blood donation, 
            organize donation drives, and maintain a robust supply of blood and its components.
        </p>
        <p>
            Join us in our mission to make a difference—because every drop counts!
        </p>
    </div>

    <div class="founders">
        <h2><i>Meet Our Founders</i></h2>
        <div class="founder">
            <img src="anjum.jpeg" alt="Anjum, Co-founder of ANRAZ Blood Bank">
            <h3>Anjum</h3>
            <p>
                Anjum, one of the co-founders of ANRAZ Blood Bank, is a passionate advocate for accessible healthcare. 
                With a strong vision and unwavering dedication, Anjum has played a vital role in establishing ANRAZ Blood Bank as a trusted name in the community.
            </p>
        </div>
        <div class="founder">
            <img src="rezan.jpeg" alt="Rezan Sohail, Co-founder of ANRAZ Blood Bank">
            <h3>Rezan Sohail</h3>
            <p>
                Rezan Sohail, co-founder of ANRAZ Blood Bank, brings extensive experience and innovative ideas to the organization. 
                Rezan's leadership has been instrumental in driving community outreach initiatives and ensuring the blood bank is equipped with advanced technology.
            </p>
        </div>
    </div>
    <div class="spacer"></div>

</main>

    <?php include 'footer.php'; ?>
</body>
</html>
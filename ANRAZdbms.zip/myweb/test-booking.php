<?php
include 'connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Retrieve form inputs
    $lab_no = $_POST['lab_no'];
    $test_date = $_POST['test_date'];
    $role = $_POST['role'];
    $patient_id = ($_POST['role'] === 'Patient') ? $_POST['patient_id'] : null;
    $donor_id = ($_POST['role'] === 'Donor') ? $_POST['donor_id'] : null;
    $mr_no = $_POST['mr_no'];
    $visit_id = $_POST['visit_id'];
    $name = $_POST['name'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $referred_by = $_POST['referred_by'];
    $contact_no = $_POST['contact_no'];
    $address = $_POST['address'];
    $clinical_remarks = $_POST['clinical_remarks'];
    $test_code = $_POST['test_code'];

    // Validate the test code
    $test_query = "SELECT * FROM testManagement WHERE testID = ?";
    $stmt = sqlsrv_query($conn, $test_query, array($test_code));
    $test_row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

    if ($test_row) {
        $test_name = $test_row['testName'];
        $test_price = $test_row['price'];
    } else {
        echo "<script>alert('Invalid test code selected.');</script>";
    }

    // Insert into the testBooking table (assuming a testBooking table exists)
    $query = "INSERT INTO testBooking (labNo, testDate, role, patientID, donorID, mrNo, visitID, name, age, gender, referredBy, contactNo, address, clinicalRemarks, testCode, testName, testPrice)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $params = [$lab_no, $test_date, $role, $patient_id, $donor_id, $mr_no, $visit_id, $name, $age, $gender, $referred_by, $contact_no, $address, $clinical_remarks, $test_code, $test_name, $test_price];
    $stmt = sqlsrv_query($conn, $query, $params);

    if ($stmt === false) {
        die(print_r(sqlsrv_errors(), true));
    } else {
        echo "<script>alert('Test booking successfully recorded!');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anraz Blood Bank - Test Booking</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        /* Retaining original styles */
        body {
            background-color: #ffffff;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .content {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        form {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }
        .form-group {
            display: flex;
            flex-direction: column;
            flex: 1 1 calc(50% - 15px);
        }
        label {
            font-weight: bold;
            margin-bottom: 5px;
        }
        input, select, textarea, button {
            padding: 10px;
            font-size: 1em;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 100%;
        }
        textarea {
            resize: vertical;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #f1f1f1;
        }
        .button-group {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            flex: 1 1 100%;
        }
        button {
            cursor: pointer;
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 15px;
            transition: background-color 0.3s;
        }
        button:hover {
            background-color: #0056b3;
        }
        .conditional-field {
            display: none;
        }
    </style>
    <script>
        function toggleRoleFields() {
            const role = document.getElementById('role').value;
            const patientField = document.getElementById('patient_id_field');
            const donorField = document.getElementById('donor_id_field');

            if (role === 'Patient') {
                patientField.style.display = 'block';
                donorField.style.display = 'none';
            } else if (role === 'Donor') {
                donorField.style.display = 'block';
                patientField.style.display = 'none';
            } else {
                patientField.style.display = 'none';
                donorField.style.display = 'none';
            }
        }

        function addTestToTable() {
            const testCode = document.getElementById('test_code').value;
            const testName = document.getElementById('test_code').options[document.getElementById('test_code').selectedIndex].text;
            const testTable = document.getElementById('test_table');
            const row = testTable.insertRow();

            // Add new test row to the table
            row.innerHTML = `
                <td>${testCode}</td>
                <td>${testName}</td>
                <td>${document.getElementById('test_price').value}</td>
                <td>${document.getElementById('test_date').value}</td>
                <td><button type="button" onclick="removeTestRow(this)">Remove</button></td>
            `;
        }

        function removeTestRow(button) {
            const row = button.parentNode.parentNode;
            row.remove();
        }
    </script>
</head>
<body>
    <?php include 'header.php'; ?>
    <main>
        <div class="content">
            <h2>Test Booking</h2>
            <p>Schedule laboratory tests for patients or donors.</p>
            <form action="process_test_booking.php" method="POST">
                <div class="form-group">
                    <label for="lab_no">Lab No:</label>
                    <input type="text" id="lab_no" name="lab_no" required>
                </div>
                <div class="form-group">
                    <label for="test_date">Test Date:</label>
                    <input type="date" id="test_date" name="test_date" required>
                </div>
                <div class="form-group">
                    <label for="role">Role:</label>
                    <select id="role" name="role" onchange="toggleRoleFields()" required>
                        <option value="">-- Select Role --</option>
                        <option value="Patient">Patient</option>
                        <option value="Donor">Donor</option>
                    </select>
                </div>
                <div class="form-group conditional-field" id="patient_id_field">
                    <label for="patient_id">Patient ID:</label>
                    <input type="number" id="patient_id" name="patient_id">
                </div>
                <div class="form-group conditional-field" id="donor_id_field">
                    <label for="donor_id">Donor ID:</label>
                    <input type="number" id="donor_id" name="donor_id">
                </div>
                <div class="form-group">
                    <label for="mr_no">MR No:</label>
                    <input type="text" id="mr_no" name="mr_no">
                </div>
                <div class="form-group">
                    <label for="visit_id">Visit ID:</label>
                    <input type="text" id="visit_id" name="visit_id">
                </div>
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="age">Age:</label>
                    <input type="number" id="age" name="age" required>
                </div>
                <div class="form-group">
                    <label for="gender">Gender:</label>
                    <select id="gender" name="gender" required>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="referred_by">Referred By:</label>
                    <input type="text" id="referred_by" name="referred_by">
                </div>
                <div class="form-group">
                    <label for="contact_no">Contact No:</label>
                    <input type="tel" id="contact_no" name="contact_no" required>
                </div>
                <div class="form-group">
                    <label for="address">Address:</label>
                    <input type="text" id="address" name="address" value="Stadium Road, Karachi, Pakistan" readonly>
                </div>
                <div class="form-group">
                    <label for="clinical_remarks">Clinical Remarks:</label>
                    <textarea id="clinical_remarks" name="clinical_remarks"></textarea>
                </div>
                <div class="form-group">
                    <label for="test_code">Select Test:</label>
                    <select id="test_code" name="test_code">
                        <option value="CBC">Complete Blood Count</option>
                        <option value="LFT">Liver Function Test</option>
                        <option value="RFT">Renal Function Test</option>
                    </select>
                    <button type="button" id="add_test" onclick="addTestToTable()">Add Test</button>
                </div>
            
            </form>
        </div>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>

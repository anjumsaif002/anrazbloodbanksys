<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anraz Blood Bank</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <main>
        <section class="hero contact-section">
            <h2>Contact Us</h2>
            <p>We are here to assist you 24/7. Reach out to us through the following contact details:</p>
            <ul>
                <li><strong>Helpline Number:</strong> +1-800-ANRAZBB (1-800-267-2922)</li>
                <li><strong>Emergency Number:</strong> +1-800-EMERGENCY (1-800-363-7436)</li>
                <li><strong>Email:</strong> <a href="mailto:support@anrazbloodbank.com">support@anrazbloodbank.com</a></li>
                <li><strong>Address:</strong> 1234 Anraz Blood Bank Avenue, Cityville, State, ZIP Code</li>
                <li><strong>Working Hours:</strong> Open 24/7 for emergencies and urgent inquiries</li>
                <li><strong>Follow Us:</strong> 
                    <a href="https://facebook.com/anrazbloodbank" target="_blank">Facebook</a> | 
                    <a href="https://twitter.com/anrazbloodbank" target="_blank">Twitter</a> | 
                    <a href="https://instagram.com/anrazbloodbank" target="_blank">Instagram</a>
                </li>
            </ul>
            <p>Your contribution matters! Contact us for more information on how to donate blood or organize a blood drive.</p>
        </section>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>

<footer>
    <div class="introduction">
        <p>ANRAZ blood bank is a healthcare organization, serving the community by providing high-quality affordable medical services in Pakistan. 
        Started in 2001, ANRAZ was formed with the aim to provide safe blood to our communities. The vision of ANRAZ has since grown to become a holistic healthcare services organization. In line with this vision, the service offerings have expanded into multiple distinct divisions.</p>
        <blockquote><b><i>"Donate blood, save lives."</i></b></blockquote>
    </div>
    <div class="social-media">
        <a href="https://facebook.com" target="_blank">Facebook</a>
        <a href="https://linkedin.com" target="_blank">LinkedIn</a>
        <a href="https://instagram.com" target="_blank">Instagram</a>
    </div>
    <div class="address-copyright">
        <p>123 Blood Bank Street, Karachi, Pakistan</p>
        <p>&copy; 2024 BBMS Blood Bank</p>
    </div>
</footer>
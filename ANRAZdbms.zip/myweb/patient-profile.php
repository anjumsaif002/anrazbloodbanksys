<?php
include 'connection.php';

$patient = null;

// Check if the form is submitted with a CNIC value
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cnic_search'])) {
    $cnic = $_POST['cnic_search'];

    // Query to fetch patient details by CNIC
    $query = "SELECT * FROM patient WHERE CNIC = ?";
    $params = array($cnic);
    $stmt = sqlsrv_query($conn, $query, $params);

    // Check if query execution is successful
    if ($stmt === false) {
        die(print_r(sqlsrv_errors(), true));
    } else {
        $patient = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Profile</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <main>
        <div class="content">
            <h2>Search Patient by CNIC</h2>
            <form action="patient-profile.php" method="POST">
                <label for="cnic_search">Enter CNIC:</label>
                <input type="text" id="cnic_search" name="cnic_search" placeholder="Enter CNIC (13 digits)" required>
                <input type="submit" value="Search">
            </form>

            <?php if ($patient === null && $_SERVER['REQUEST_METHOD'] === 'POST'): ?>
                <p style="color: red; font-weight: bold;">No patient found with the provided CNIC.</p>
            <?php elseif ($patient !== null): ?>
                <h3>Patient Details</h3>
                <form action="update_patient_profile.php" method="POST">
                    <fieldset>
                        <legend>Patient Information</legend>

                        <label for="patientID">Patient ID:</label>
                        <input type="text" id="patientID" name="patientID" value="<?php echo htmlspecialchars($patient['patientID']); ?>" readonly><br><br>

                        <label for="patientName">Patient Name:</label>
                        <input type="text" id="patientName" name="patientName" value="<?php echo htmlspecialchars($patient['patientName']); ?>" required><br><br>

                        <label for="age">Age:</label>
                        <input type="number" id="age" name="age" value="<?php echo htmlspecialchars($patient['age']); ?>" required><br><br>

                        <label for="gender">Gender:</label>
                        <select id="gender" name="gender" required>
                            <option value="Male" <?php echo ($patient['gender'] === 'Male') ? 'selected' : ''; ?>>Male</option>
                            <option value="Female" <?php echo ($patient['gender'] === 'Female') ? 'selected' : ''; ?>>Female</option>
                            <option value="Other" <?php echo ($patient['gender'] === 'Other') ? 'selected' : ''; ?>>Other</option>
                        </select><br><br>

                        <label for="cnic">CNIC:</label>
                        <input type="text" id="cnic" name="cnic" value="<?php echo htmlspecialchars($patient['CNIC']); ?>" readonly><br><br>

                        <label for="bloodType">Blood Type:</label>
                        <select id="bloodType" name="bloodType" required>
                            <option value="A+" <?php echo ($patient['bloodType'] === 'A+') ? 'selected' : ''; ?>>A+</option>
                            <option value="A-" <?php echo ($patient['bloodType'] === 'A-') ? 'selected' : ''; ?>>A-</option>
                            <option value="B+" <?php echo ($patient['bloodType'] === 'B+') ? 'selected' : ''; ?>>B+</option>
                            <option value="B-" <?php echo ($patient['bloodType'] === 'B-') ? 'selected' : ''; ?>>B-</option>
                            <option value="O+" <?php echo ($patient['bloodType'] === 'O+') ? 'selected' : ''; ?>>O+</option>
                            <option value="O-" <?php echo ($patient['bloodType'] === 'O-') ? 'selected' : ''; ?>>O-</option>
                            <option value="AB+" <?php echo ($patient['bloodType'] === 'AB+') ? 'selected' : ''; ?>>AB+</option>
                            <option value="AB-" <?php echo ($patient['bloodType'] === 'AB-') ? 'selected' : ''; ?>>AB-</option>
                        </select><br><br>

                        <label for="contact">Contact Number:</label>
                        <input type="tel" id="contact" name="contact" value="<?php echo htmlspecialchars($patient['contact']); ?>" required><br><br>

                        <label for="address">Address:</label><br>
                        <textarea id="address" name="address" rows="4" cols="50" required><?php echo htmlspecialchars($patient['address']); ?></textarea><br><br>

                        <input type="submit" value="Update Profile">
                    </fieldset>
                </form>
            <?php endif; ?>
        </div>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>

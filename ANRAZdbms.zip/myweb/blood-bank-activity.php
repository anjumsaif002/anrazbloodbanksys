<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anraz Blood Bank - Activity Log</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <main>
        <div class="content">
            <h2>Blood Bank Activity</h2>
            <p>Log details of recent blood donations and transfusions.</p>
            <form action="process_blood_activity.php" method="POST">
                <div class="form-group">
                    <label for="activity_id">Activity ID:</label>
                    <input type="text" id="activity_id" name="activity_id" required>
                </div>
                <div class="form-group">
                    <label for="activity_date">Activity Date:</label>
                    <input type="date" id="activity_date" name="activity_date" required>
                </div>
                <div class="form-group">
                    <label for="activity_type">Activity Type:</label>
                    <select id="activity_type" name="activity_type" required>
                        <option value="Donation">Donation</option>
                        <option value="Transfusion">Transfusion</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="blood_group">Blood Group:</label>
                    <select id="blood_group" name="blood_group" required>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="units">Units:</label>
                    <input type="number" id="units" name="units" required>
                </div>
                <div class="form-group">
                    <label for="performed_by">Performed By:</label>
                    <input type="text" id="performed_by" name="performed_by" required>
                </div>
                <div class="form-group">
                    <label for="remarks">Remarks:</label>
                    <textarea id="remarks" name="remarks"></textarea>
                </div>
                <div class="button-group">
                    <button type="submit" name="save">Save</button>
                    <button type="button" name="edit">Edit</button>
                    <button type="button" name="refresh">Refresh</button>
                    <button type="button" name="close">Close</button>
                </div>
            </form>
        </div>
    </main>
    <?php include 'footer.php'; ?>
</body>
</html>

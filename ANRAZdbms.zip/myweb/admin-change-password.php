<?php
session_start(); // Start the session

// Include the database connection file
include 'connection.php';

// Initialize the error and success messages
$error_message = "";
$success_message = "";

// Check if the user is logged in
if (!isset($_SESSION['adminID'])) {
    header("Location: admin-change-password.php"); // Redirect to login if not logged in
    exit();
}

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and get the form input values
    $username = $_POST['username'];
    $current_password = $_POST['current-password'];
    $new_password = $_POST['new-password'];
    $confirm_password = $_POST['confirm-password'];

    // Check if the new password and confirm password match
    if ($new_password !== $confirm_password) {
        $error_message = "New password and confirmation do not match.";
    } else {
        // Prepare SQL query to find the user in the 'admins' table
        $query = "SELECT * FROM admins WHERE username = ?";
        $params = [$username];
        
        // Execute the query
        $stmt = sqlsrv_query($conn, $query, $params);

        // Check if the user is found
        if ($stmt === false) {
            die(print_r(sqlsrv_errors(), true)); // Handle errors
        }

        $user = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC);

        // If a user is found, check the current password
        if ($user) {
            // Directly compare the current password with the database-stored password
            if ($user['password'] === $current_password) {
                // Current password is correct, update to the new password
                $new_password_hashed = password_hash($new_password, PASSWORD_BCRYPT); // Hash the new password

                // Update the password in the database
                $update_query = "UPDATE admins SET password = ? WHERE username = ?";
                $update_params = [$new_password_hashed, $username];
                
                $update_stmt = sqlsrv_query($conn, $update_query, $update_params);

                if ($update_stmt === false) {
                    die(print_r(sqlsrv_errors(), true)); // Handle errors
                }

                // Success, set the success message
                $success_message = "Password successfully updated.";
                // Redirect to the same page to display success message
                header("Location: admin-change-password.php?success=true");
                exit(); // Make sure the script stops here after redirection
            } else {
                // Current password is incorrect
                $error_message = "Current password is incorrect.";
            }
        } else {
            // User not found
            $error_message = "User not found.";
        }
    }
}

// Check if the success message is passed via URL query parameters
if (isset($_GET['success']) && $_GET['success'] === 'true') {
    $success_message = "Password successfully changed.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anraz Blood Bank - Change Password</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'header.php'; ?>
    
    <main>
        <div class="content">
            <h2>Change Password</h2>
            
            <!-- Display error message if exists -->
            <?php if (!empty($error_message)): ?>
                <div class="error-message" style="color: red; font-weight: bold;">
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>

            <!-- Display success message if password is changed -->
            <?php if (!empty($success_message)): ?>
                <div class="success-message" style="color: green; font-weight: bold;">
                    <?php echo $success_message; ?>
                </div>
            <?php endif; ?>

            <!-- Password change form -->
            <form method="POST" action="admin-change-password.php">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" value="<?php echo $_SESSION['username']; ?>" required readonly>

                <label for="current-password">Current Password:</label>
                <input type="password" id="current-password" name="current-password" required>

                <label for="new-password">New Password:</label>
                <input type="password" id="new-password" name="new-password" required>

                <label for="confirm-password">Confirm New Password:</label>
                <input type="password" id="confirm-password" name="confirm-password" required>

                <button type="submit">Change Password</button>
            </form>
        </div>
    </main>

    <?php include 'footer.php'; ?>
</body>
</html>

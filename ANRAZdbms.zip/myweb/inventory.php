<?php
include 'connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inventoryID = $_POST['inventoryID'];
    $newUnits = $_POST['units'];
    $currentDate = date('Y-m-d H:i:s');

    // SQL to update the units and date
    $sql = "UPDATE inventory SET units = ?, updatedDate = ? WHERE inventoryID = ?";
    $params = array($newUnits, $currentDate, $inventoryID);
    $stmt = sqlsrv_query($conn, $sql, $params);

    if ($stmt === false) {
        die(print_r(sqlsrv_errors(), true));
    } else {
        echo "<script>alert('Inventory updated successfully!');</script>";
    }
}

$sql = "SELECT inventoryID, bloodType, units, updatedDate FROM inventory";
$stmt = sqlsrv_query($conn, $sql);

if ($stmt === false) {
    die(print_r(sqlsrv_errors(), true));
}

$inventoryData = [];
while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
    $inventoryData[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anraz Blood Bank</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .content {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        h2 {
            text-align: center;
            color: #333;
            font-size: 1.5em;
        }
        p {
            text-align: center;
            font-size: 1em;
            color: #555;
        }
        .box-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
            margin-top: 20px;
        }
        .box-container {
            background-color: rgb(187, 67, 56);
            color: white;
            padding: 15px;
            text-align: center;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(122, 115, 115, 0.57);
            transition: background-color 0.3s ease;
            cursor: pointer;
        }
        .box-container h3 {
            font-size: 2em;  /* Even bigger font size for blood group */
            margin-bottom: 5px;
        }
        .box-container p {
            font-size: 1em;
            color: white;
            margin-bottom: 3px;
        }
        .box-container .updated {
            font-size: 0.8em;
            color: lightgray;
        }
        .box-container:hover {
            background-color: #7b3c33;
        }
        .edit-form {
            display: none;
            margin-top: 10px;
        }
        .box-container.active {
            background-color: #7b3c33;
        }
        .box-container input {
            width: 100px;
            padding: 5px;
            font-size: 1em;
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>
    <main>
        <div class="content">
            <h2>Blood Bank Inventory</h2>
            <p>Below is the current inventory of available blood types and their details:</p>
            <div class="box-grid">
                <?php
                    foreach ($inventoryData as $inventoryItem) {
                        // Format updated date
                        $updatedDate = $inventoryItem['updatedDate'] ? $inventoryItem['updatedDate']->format('d-m-Y H:i') : 'N/A';
                        echo "<div class='box-container' id='bloodType_" . htmlspecialchars($inventoryItem['inventoryID']) . "' onclick='editUnits(" . htmlspecialchars($inventoryItem['inventoryID']) . ")'>
                                <h3>" . htmlspecialchars($inventoryItem['bloodType']) . "</h3>
                                <p>Units: <span id='units_" . htmlspecialchars($inventoryItem['inventoryID']) . "'>" . htmlspecialchars($inventoryItem['units']) . "</span></p>
                                <p class='updated'>Last Updated: " . htmlspecialchars($updatedDate) . "</p>
                                <div class='edit-form' id='editForm_" . htmlspecialchars($inventoryItem['inventoryID']) . "'>
                                    <form method='POST'>
                                        <input type='number' name='units' id='inputUnits_" . htmlspecialchars($inventoryItem['inventoryID']) . "' value='" . htmlspecialchars($inventoryItem['units']) . "' required>
                                        <input type='hidden' name='inventoryID' value='" . htmlspecialchars($inventoryItem['inventoryID']) . "'>
                                        <button type='submit'>Update</button>
                                    </form>
                                </div>
                              </div>";
                    }
                ?>
            </div>
        </div>
    </main>
    <?php include 'footer.php'; ?>

    <script>
        function editUnits(inventoryID) {
            // Toggle the edit form for the clicked blood type
            var form = document.getElementById('editForm_' + inventoryID);
            var container = document.getElementById('bloodType_' + inventoryID);
            form.style.display = form.style.display === 'block' ? 'none' : 'block';
            container.classList.toggle('active');
        }
    </script>
</body>
</html>

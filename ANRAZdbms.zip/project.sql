create database proj3;

create table donor(
	donorID int primary key,
	donorName varchar(50) not NULL,
	CNIC char(13) not NULL,
	age int not NULL,
	gender varchar(6),
	contact char(11),
	address varchar(200),
	bloodType varchar(3) not NULL,
	lastDonatedDate smalldatetime
);

create table patient(
	patientID int primary key,
	patientName varchar(50) not NULL,
	CNIC char(13),
	age int not NULL,
	gender varchar(6),
	contact char(11),
	address varchar(200),
	bloodType varchar(3) not NULL
);

create table admins(
	adminID int primary key,
	username varchar(20),
	password varchar(20)not NULL
);

create table laboratory(
	labID int primary key,
	labName varchar(20) not NULL,
	reportStatus varchar(15)
);

create table donation(
	donationID int primary key,
	donationDate smalldatetime not NULL,
	donorID int foreign key references donor(donorID)
);

create table medicineTrials(
	trialID int primary key,
    trialName varchar(50) not NULL,
    status varchar(50) not NULL,
    duration int not NULL --in weeks?
);

CREATE TABLE bloodBooking (
    bloodBookingID INT PRIMARY KEY,
    name VARCHAR(30) NOT NULL,
    bookingDate smalldatetime NOT NULL,
    bloodType VARCHAR(3) NOT NULL,
    contact CHAR(11) NOT NULL,
    units INT NOT NULL,
    patientID INT FOREIGN KEY (patientID) REFERENCES patient(patientID),
    donorID INT FOREIGN KEY (donorID) REFERENCES donor(donorID)
);

CREATE TABLE testBooking (
    testBookingID INT PRIMARY KEY,
    testName VARCHAR(20) NOT NULL,
    testDate SMALldatetime NOT NULL,
    labNo INT,
    medicalRNo INT,
    visitID INT,
    age INT,
    gender VARCHAR(6),
    bloodType VARCHAR(3) NOT NULL,
    testBookingName VARCHAR(50),
    contact CHAR(11),
    patientID INT FOREIGN KEY (patientID) REFERENCES patient(patientID),
    donorID INT FOREIGN KEY (donorID) REFERENCES donor(donorID)
);

create table testManagement(
	testID int primary key,
	testName varchar(20),
	price money,
	testDate smalldatetime
);

create table inventory(
	inventoryID int primary key,
	bloodType varchar(3) not NULL,
	units int not NULL,
	updatedDate smalldatetime
);

create table counter(
	counterID int primary key,
	status varchar(15),
	counterType varchar(15)
);

INSERT INTO patient (patientID, patientName, CNIC, age, gender, contact, address, bloodType)
VALUES 
(1, 'John Doe', '1234567890123', 30, 'Male', '03001234567', 'Karachi, Sindh', 'A+'),
(2, 'Sarah Khan', '1234567890124', 40, 'Female', '03201234567', 'Lahore, Punjab', 'O-'),
(3, 'Zainab Ali', '1234567890125', 25, 'Female', '03401234567', 'Islamabad, FCT', 'A-'),
(4, 'Fatima Rahman', '1234567890126', 35, 'Female', '03601234567', 'Rawalpindi, Punjab', 'O+'),
(5, 'Ayesha Iqbal', '1234567890127', 28, 'Female', '03801234567', 'Karachi, Sindh', 'B+'),
(6, 'Raza Shafi', '1234567890128', 50, 'Male', '03901234567', 'Multan, Punjab', 'A+'),
(7, 'Shahzaib Ali', '1234567890129', 38, 'Male', '04101234568', 'Karachi, Sindh', 'B+'),
(8, 'Mariam Shah', '1234567890130', 45, 'Female', '04301234569', 'Peshawar, KPK', 'AB+'),
(9, 'Sana Farooq', '1234567890131', 32, 'Female', '04401234570', 'Faisalabad, Punjab', 'O+'),
(10, 'Omer Khan', '1234567890132', 27, 'Male', '04501234571', 'Lahore, Punjab', 'B-');

INSERT INTO donor (donorID, donorName, CNIC, age, gender, contact, address, bloodType, lastDonatedDate)
VALUES 
(1, 'Alice Smith', '1234567890131', 32, 'Female', '03101234567', 'Karachi, Sindh', 'B+', '2024-10-01'),
(2, 'Bilal Ahmed', '1234567890132', 38, 'Male', '03301234567', 'Lahore, Punjab', 'AB+', '2024-08-15'),
(3, 'Faisal Malik', '1234567890133', 29, 'Male', '03501234567', 'Islamabad, FCT', 'B-', '2024-09-20'),
(4, 'Usman Khan', '1234567890134', 42, 'Male', '03701234567', 'Rawalpindi, Punjab', 'AB-', '2024-07-10'),
(5, 'Raza Shafi', '1234567890135', 50, 'Male', '03901234567', 'Multan, Punjab', 'A+', '2024-05-25'),
(6, 'Hassan Javed', '1234567890136', 28, 'Male', '04001234567', 'Karachi, Sindh', 'O+', '2024-12-15'),
(7, 'Mariam Shah', '1234567890137', 33, 'Female', '04101234567', 'Quetta, Balochistan', 'O+', '2024-09-25'),
(8, 'Sana Jamil', '1234567890138', 27, 'Female', '04201234567', 'Islamabad, FCT', 'A+', '2024-11-05'),
(9, 'Khan Mehmood', '1234567890139', 40, 'Male', '04301234567', 'Sialkot, Punjab', 'AB+', '2024-04-18'),
(10, 'Rashid Ali', '1234567890140', 45, 'Male', '04401234567', 'Karachi, Sindh', 'O+', '2024-06-12');

insert into admins values
(1, 'rezan', 'r123');

-- Blood Booking by Patient
INSERT INTO bloodBooking (bloodBookingID, name, bookingDate, bloodType, contact, units, patientID)
VALUES (1, 'John Doe', '2025-01-05 10:00', 'A+', '03001234567', 2, 1);

-- Blood Booking by Donor
INSERT INTO bloodBooking (bloodBookingID, name, bookingDate, bloodType, contact, units, donorID)
VALUES (2, 'Alice Smith', '2025-01-06 11:30', 'B+', '03101234567', 1, 2);

-- Blood Booking by Patient
INSERT INTO bloodBooking (bloodBookingID, name, bookingDate, bloodType, contact, units, patientID)
VALUES (3, 'Sarah Khan', '2025-01-07 14:00', 'O-', '03201234567', 3, 3);

-- Blood Booking by Donor
INSERT INTO bloodBooking (bloodBookingID, name, bookingDate, bloodType, contact, units, donorID)
VALUES (4, 'Bilal Ahmed', '2025-01-08 15:00', 'AB+', '03301234567', 2, 4);

-- Blood Booking by Patient
INSERT INTO bloodBooking (bloodBookingID, name, bookingDate, bloodType, contact, units, patientID)
VALUES (5, 'Zainab Ali', '2025-01-10 09:30', 'A-', '03401234567', 1, 5);

-- Blood Booking by Donor
INSERT INTO bloodBooking (bloodBookingID, name, bookingDate, bloodType, contact, units, donorID)
VALUES (6, 'Faisal Malik', '2025-01-12 13:00', 'B-', '03501234567', 1, 6);

-- Blood Booking by Patient
INSERT INTO bloodBooking (bloodBookingID, name, bookingDate, bloodType, contact, units, patientID)
VALUES (7, 'Fatima Rahman', '2025-01-14 10:45', 'O+', '03601234567', 2, 7);

-- Blood Booking by Donor
INSERT INTO bloodBooking (bloodBookingID, name, bookingDate, bloodType, contact, units, donorID)
VALUES (8, 'Usman Khan', '2025-01-15 11:15', 'AB-', '03701234567', 1, 8);

-- Blood Booking by Patient
INSERT INTO bloodBooking (bloodBookingID, name, bookingDate, bloodType, contact, units, patientID)
VALUES (9, 'Ayesha Iqbal', '2025-01-16 08:30', 'B+', '03801234567', 2, 9);

-- Blood Booking by Donor
INSERT INTO bloodBooking (bloodBookingID, name, bookingDate, bloodType, contact, units, donorID)
VALUES (10, 'Raza Shafi', '2025-01-18 10:00', 'A+', '03901234567', 3, 10);


insert into inventory values
(1, 'O+', 30, '2025-01-01'),  -- Common blood type
(2, 'A+', 25, '2025-01-01'),
(3, 'B+', 20, '2025-01-01'),
(4, 'AB+', 15, '2025-01-01'), -- Universal recipient
(5, 'O-', 12, '2025-01-01'),  -- Universal donor
(6, 'A-', 10, '2025-01-01'),
(7, 'B-', 8, '2025-01-01'),
(8, 'AB-', 4, '2025-01-01');  -- Rare blood type

insert into laboratory values
(1, 'Lab A', 'Completed'),
(2, 'Lab A', 'Pending'),
(3, 'Lab A', 'In Progress');

INSERT INTO donation (donationID, donationDate, donorID)
VALUES
(1, '2025-01-01', 1),  -- Alice Smith
(2, '2024-12-15', 2),  -- Bilal Ahmed
(3, '2024-12-10', 3),  -- Faisal Malik
(4, '2024-12-05', 4),  -- Usman Khan
(5, '2024-11-10', 5),  -- Raza Shafi
(6, '2024-10-30', 6),  -- Hassan Javed
(7, '2024-09-25', 7),  -- Mariam Shah
(8, '2024-09-10', 8);  -- Sana Jamil

insert into medicineTrials values
(1, 'Transfuse Trial', 'Active', 2),
(2, 'Bloodsafe Trial', 'Completed', 16),
(3, 'Plasma Trial', 'Active', 8),
(4, 'Bloodmatch Trial', 'Pending', 14),
(5, 'Transfuse Trial', 'Completed', 15),
(6, 'Hemostasis Trial', 'Ongoing', 20),
(7, 'Component Trial', 'Completed', 15),
(8, 'Transfusion Trial', 'Pending', 24);

insert into testManagement values
(1, 'CBC', 1200.00, '2025-01-01'),
(2, 'LFT', 1500.00, '2025-01-01'),
(3, 'RFT', 1800.00, '2025-01-01'),
(4, 'Blood Sugar', 1000.00, '2025-01-01');

insert into counter values
(1, 'Open', 'Blood Donation'),
(2, 'Open', 'Test Booking'),
(3, 'Close', 'Blood Donation'),
(4, 'Close', 'Test Booking');


-- Test Booking by Patient
INSERT INTO testBooking (testBookingID, testName, testDate, labNo, medicalRNo, visitID, age, gender, bloodType, testBookingName, contact, patientID)
VALUES (1, 'CBC', '2025-01-05 10:00', 101, 12345, 1, 30, 'Male', 'A+', 'Blood Test', '03001234567', 1);

-- Test Booking by Donor
INSERT INTO testBooking (testBookingID, testName, testDate, labNo, medicalRNo, visitID, age, gender, bloodType, testBookingName, contact, donorID)
VALUES (2, 'LFT', '2025-01-06 11:30', 102, 12346, 2, 45, 'Female', 'B+', 'Liver Function Test', '03101234567', 2);

-- Test Booking by Patient
INSERT INTO testBooking (testBookingID, testName, testDate, labNo, medicalRNo, visitID, age, gender, bloodType, testBookingName, contact, patientID)
VALUES (3, 'RFT', '2025-01-07 14:30', 103, 12347, 3, 40, 'Female', 'O-', 'Renal Function Test', '03201234567', 3);

-- Test Booking by Donor
INSERT INTO testBooking (testBookingID, testName, testDate, labNo, medicalRNo, visitID, age, gender, bloodType, testBookingName, contact, donorID)
VALUES (4, 'Hepatitis B Test', '2025-01-09 09:00', 104, 12348, 4, 38, 'Male', 'AB+', 'Hepatitis B Screening', '03301234567', 4);

-- Test Booking by Patient
INSERT INTO testBooking (testBookingID, testName, testDate, labNo, medicalRNo, visitID, age, gender, bloodType, testBookingName, contact, patientID)
VALUES (5, 'CBC', '2025-01-10 11:30', 105, 12349, 5, 25, 'Male', 'A-', 'Blood Test', '03401234567', 5);

-- Test Booking by Donor
INSERT INTO testBooking (testBookingID, testName, testDate, labNo, medicalRNo, visitID, age, gender, bloodType, testBookingName, contact, donorID)
VALUES (6, 'Blood Typing', '2025-01-12 13:45', 106, 12350, 6, 29, 'Female', 'B-', 'Blood Group Identification', '03501234567', 6);

-- Test Booking by Patient
INSERT INTO testBooking (testBookingID, testName, testDate, labNo, medicalRNo, visitID, age, gender, bloodType, testBookingName, contact, patientID)
VALUES (7, 'HIV Test', '2025-01-14 15:00', 107, 12351, 7, 35, 'Female', 'O+', 'HIV Screening', '03601234567', 7);

-- Test Booking by Donor
INSERT INTO testBooking (testBookingID, testName, testDate, labNo, medicalRNo, visitID, age, gender, bloodType, testBookingName, contact, donorID)
VALUES (8, 'Blood Pressure Test', '2025-01-16 10:15', 108, 12352, 8, 42, 'Male', 'AB-', 'Blood Pressure Check', '03701234567', 8);

-- Test Booking by Patient
INSERT INTO testBooking (testBookingID, testName, testDate, labNo, medicalRNo, visitID, age, gender, bloodType, testBookingName, contact, patientID)
VALUES (9, 'Thyroid Test', '2025-01-17 09:30', 109, 12353, 9, 28, 'Female', 'B+', 'Thyroid Function Test', '03801234567', 9);

-- Test Booking by Donor
INSERT INTO testBooking (testBookingID, testName, testDate, labNo, medicalRNo, visitID, age, gender, bloodType, testBookingName, contact, donorID)
VALUES (10, 'Liver Function Test', '2025-01-18 12:00', 110, 12354, 10, 50, 'Male', 'A+', 'Liver Function Screening', '03901234567', 10);

-- Stored Procedure: Get Donation Details by Donor
CREATE PROCEDURE GetDonationDetailsByDonor
    @donorID INT
AS
BEGIN
    SELECT 
        dn.donationID,
        dn.donationDate,
        d.donorName,
        d.bloodType
    FROM donation dn
    JOIN donor d ON dn.donorID = d.donorID
    WHERE d.donorID = @donorID
    ORDER BY dn.donationDate DESC;
END;

-- View: Patient Blood Type Summary
CREATE VIEW PatientBloodTypeSummary AS
SELECT 
    bloodType,
    COUNT(patientID) AS TotalPatients
FROM patient
GROUP BY bloodType
ORDER BY TotalPatients DESC;

-- View: Blood Donation History
CREATE VIEW BloodDonationHistory AS
SELECT 
    d.donorName,
    d.bloodType,
    d.contact,
    dn.donationDate
FROM donor d
JOIN donation dn ON d.donorID = dn.donorID
ORDER BY dn.donationDate DESC;